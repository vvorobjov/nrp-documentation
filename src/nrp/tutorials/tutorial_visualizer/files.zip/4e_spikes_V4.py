import hbp_nrp_cle.tf_framework as nrp
@nrp.NeuronMonitor(nrp.brain.V4, nrp.spike_recorder)
def all_spikes_monitor_V4(t):
	return True