import hbp_nrp_cle.tf_framework as nrp
@nrp.NeuronMonitor(nrp.brain.V2Layer4, nrp.spike_recorder)
def all_spikes_monitor_V2_L4(t):
	return True