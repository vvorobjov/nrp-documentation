import hbp_nrp_cle.tf_framework as nrp
@nrp.NeuronMonitor(nrp.brain.LGN, nrp.spike_recorder)
def all_spikes_monitor_LGN(t):
	return True