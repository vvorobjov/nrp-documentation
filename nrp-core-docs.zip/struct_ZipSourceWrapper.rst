.. index:: pair: struct; ZipSourceWrapper
.. _doxid-struct_zip_source_wrapper:

struct ZipSourceWrapper
=======================

.. toctree::
	:hidden:




.. ref-code-block:: cpp
	:class: doxyrest-overview-code-block

	
	struct ZipSourceWrapper {
		// construction
	
		:target:`ZipSourceWrapper<doxid-struct_zip_source_wrapper_1adb2a65ffdcf475c3df5d8082d116da65>`(zip_source_t* zip_source);

		// methods
	
		:target:`operator zip_source_t *<doxid-struct_zip_source_wrapper_1a9c829ed26166e0cf0e3b231cf392e92c>` () const;
	};
