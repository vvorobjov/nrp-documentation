.. index:: pair: class; node_policies_ns::functional_node_ns
.. _doxid-classnode__policies__ns_1_1functional__node__ns:

class node_policies_ns::functional_node_ns
==========================================

.. toctree::
	:hidden:



