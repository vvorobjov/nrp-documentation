.. index:: pair: class; node_policies_ns::output_node_ns
.. _doxid-classnode__policies__ns_1_1output__node__ns:

class node_policies_ns::output_node_ns
======================================

.. toctree::
	:hidden:



