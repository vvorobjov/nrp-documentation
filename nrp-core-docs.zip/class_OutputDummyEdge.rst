.. index:: pair: class; OutputDummyEdge
.. _doxid-class_output_dummy_edge:

class OutputDummyEdge
=====================

.. toctree::
	:hidden:




.. ref-code-block:: cpp
	:class: doxyrest-overview-code-block

	#include <output_dummy.h>
	
	class OutputDummyEdge: public :ref:`SimpleOutputEdge<doxid-class_simple_output_edge>` {
	public:
		// construction
	
		:target:`OutputDummyEdge<doxid-class_output_dummy_edge_1a9f71db1729e28241798146d8757bef28>`(const std::string& keyword, const std::string& id);
	};

Inherited Members
-----------------

.. ref-code-block:: cpp
	:class: doxyrest-overview-inherited-code-block

	public:
		// methods
	
		boost::python::object :ref:`pySetup<doxid-class_simple_output_edge_1ac9393b03ca5a6708fec5b48936210ab3>`(const boost::python::object& obj);

