.. index:: pair: struct; tuple_array<T, 0>
.. _doxid-structtuple__array_3_01_t_00_010_01_4:

template struct tuple_array<T, 0>
=================================

.. toctree::
	:hidden:




.. ref-code-block:: cpp
	:class: doxyrest-overview-code-block

	#include <functional_node.h>
	
	template <typename T>
	struct tuple_array<T, 0> {
		// fields
	
		decltype(std::tuple<>()) typedef :target:`type<doxid-structtuple__array_3_01_t_00_010_01_4_1a9d424026cb4d114a0dc27a81182ee85a>`;
	};
