.. index:: pair: class; numpy_json_serializer::NumpyEncoder
.. _doxid-classnumpy__json__serializer_1_1_numpy_encoder:

class numpy_json_serializer::NumpyEncoder
=========================================

.. toctree::
	:hidden:

.. code-block:: cpp

	Special json encoder for numpy types


.. ref-code-block:: cpp
	:class: doxyrest-overview-code-block

	
	class NumpyEncoder: public JSONEncoder {
	public:
		// methods
	
		def :target:`default<doxid-classnumpy__json__serializer_1_1_numpy_encoder_1abdc06ada41db5dc84bbaecccf1342c5d>`(self self, obj obj);
	};
