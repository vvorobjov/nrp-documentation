.. index:: pair: class; node_policies_ns::input_node_ns
.. _doxid-classnode__policies__ns_1_1input__node__ns:

class node_policies_ns::input_node_ns
=====================================

.. toctree::
	:hidden:



