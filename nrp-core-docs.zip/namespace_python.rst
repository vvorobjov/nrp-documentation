.. index:: pair: namespace; python
.. _doxid-namespaceboost_1_1python:

namespace python
================

.. toctree::
	:hidden:



