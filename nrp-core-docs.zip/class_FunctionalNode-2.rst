.. index:: pair: class; FunctionalNode
.. _doxid-class_functional_node:

template class FunctionalNode
=============================

.. toctree::
	:hidden:




.. ref-code-block:: cpp
	:class: doxyrest-overview-code-block

	#include <functional_node.h>
	
	template <typename, typename>
	class FunctionalNode {
	};

	// direct descendants

	class :ref:`PythonFunctionalNode<doxid-class_python_functional_node>`;
