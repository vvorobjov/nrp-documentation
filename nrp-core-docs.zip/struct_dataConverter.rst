.. index:: pair: struct; dataConverter<bpy::object, T_OUT>
.. _doxid-structdata_converter_3_01bpy_1_1object_00_01_t___o_u_t_01_4:

template struct dataConverter<bpy::object, T_OUT>
=================================================

.. toctree::
	:hidden:




.. ref-code-block:: cpp
	:class: doxyrest-overview-code-block

	#include <data_conversion.h>
	
	template <class T_OUT>
	struct dataConverter<bpy::object, T_OUT> {
		// methods
	
		static void :target:`convert<doxid-structdata_converter_3_01bpy_1_1object_00_01_t___o_u_t_01_4_1a754700f49b2c1315aa8728c1b87c6cfd>`(const bpy::object* d1, T_OUT& d2);
	};
