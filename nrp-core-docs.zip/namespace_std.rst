.. index:: pair: namespace; std
.. _doxid-namespacestd:

namespace std
=============

.. toctree::
	:hidden:



