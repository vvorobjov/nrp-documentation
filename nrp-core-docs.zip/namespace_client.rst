.. index:: pair: namespace; client
.. _doxid-namespaceclient:

namespace client
================

.. toctree::
	:hidden:

	class_client_NrpCore.rst




.. ref-code-block:: cpp
	:class: doxyrest-overview-code-block

	
	namespace client {

	// classes

	class :ref:`NrpCore<doxid-classclient_1_1_nrp_core>`;

	} // namespace client
