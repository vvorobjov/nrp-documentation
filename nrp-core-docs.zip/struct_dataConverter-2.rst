.. index:: pair: struct; dataConverter<T_IN, bpy::object>
.. _doxid-structdata_converter_3_01_t___i_n_00_01bpy_1_1object_01_4:

template struct dataConverter<T_IN, bpy::object>
================================================

.. toctree::
	:hidden:




.. ref-code-block:: cpp
	:class: doxyrest-overview-code-block

	#include <data_conversion.h>
	
	template <class T_IN>
	struct dataConverter<T_IN, bpy::object> {
		// methods
	
		static void :target:`convert<doxid-structdata_converter_3_01_t___i_n_00_01bpy_1_1object_01_4_1a63071f672213b0927d54ce0e1a5e49b2>`(const T_IN* d1, bpy::object& d2);
	};
