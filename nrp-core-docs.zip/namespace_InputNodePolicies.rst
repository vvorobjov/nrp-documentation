.. index:: pair: namespace; InputNodePolicies
.. _doxid-namespace_input_node_policies:

namespace InputNodePolicies
===========================

.. toctree::
	:hidden:

	enum_InputNodePolicies_MsgCachePolicy.rst
	enum_InputNodePolicies_MsgPublishPolicy.rst




.. ref-code-block:: cpp
	:class: doxyrest-overview-code-block

	
	namespace InputNodePolicies {

	// enums

	enum :ref:`MsgCachePolicy<doxid-namespace_input_node_policies_1a6e6c639f025a1af2a05b3f20e6b207a5>`;
	enum :ref:`MsgPublishPolicy<doxid-namespace_input_node_policies_1ae65f9d4505207aa68b30fb0419c73035>`;

	} // namespace InputNodePolicies
