.. index:: pair: class; python::OpenSimEngineScript
.. _doxid-classpython_1_1_open_sim_engine_script:

class python::OpenSimEngineScript
=================================

.. toctree::
	:hidden:




.. ref-code-block:: cpp
	:class: doxyrest-overview-code-block

	
	class OpenSimEngineScript: public EngineScript {
	public:
		// methods
	
		def :target:`sim_manager<doxid-classpython_1_1_open_sim_engine_script_1aef6c6864693c5c8d0ff06901c37868c2>`(self self);
	};
